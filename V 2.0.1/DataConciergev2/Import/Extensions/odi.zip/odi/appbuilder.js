define( [
    "./session/odisession",
  	"jquery",
    "js/qlik"
], function (ODISession,  $, qlik) {

  function createAppBuilder() {
    var curApp = qlik.currApp();

    // session mgt variables
    var newAppSession;
    var newAppHandle;
    var newAppId;
    var templateAppId;
    var templateAppSession;
    var templateAppHandle;

    var sharedSession = null;


    // script binding variables
    var templAppScript;
    var onDemandScript = null;
    var quoteCharacter;
    var quoteChrRegEx;
    var neededFlds = null;
    var matchesInPosOrder = null;
    var shopperAppFields = null;
    var newAppName = '';
    var oldestPriorOddAppId = null;
    var numRegExp = new RegExp("^\\s*[\\d,]+\\s*$", "gmi");
    var delimiter;

    // Reload progress vars
    var continueMonitoring = false;
    var lastProgWasNumber = false;

    // navigational variables
    var targetAppSheetId = null;

    // shared state from controller
    var translator;
    var scope;
    var layout;

    // desktop status
    var checkedDesktop = false;
    var isDesktop = false;

    // search for all patterns of the form: $(od[s|a|n]_<FIELDNAME>)[2-4]
    // where the [2-4] is actually [*] and optional
    var bindExpRegEx = new RegExp("\\$\\(od([s]?[o]?[x]?)_([^\\)]*)\\)(\\[[^\\]]*\\])?", "gim");

    // pattern for matching selected value quantity range content inside []:  M, M+, M- or M-N
    var qtySpecRegEx = new RegExp("^([\\d]+)\\s*(([-+])\\s*([\\d]+)?)?$", "gim");


    /*** Utility Functions ***/
    var CloseSession = function (session) {
      if (session) {
        session.close();
      }
      return null;
    };

    var LogError = function (text) {
      scope.errorCount++;
      scope.view = "error";
      scope.lastError = text;
      if (scope.errorCount === 1) {	//we only need to do this once
        templateAppSession = CloseSession(templateAppSession);
        newAppSession = CloseSession(newAppSession);
        sharedSession = CloseSession(sharedSession);
      }
    };

    var LogProcess = function (text) {
      scope.progress = text;
    };

    var EscapeRegExSpChr = function (wrapChr) {
      if (wrapChr === '[' ||
        wrapChr === '\\' ||
        wrapChr === '^' ||
        wrapChr === '$' ||
        wrapChr === '.' ||
        wrapChr === '|' ||
        wrapChr === '?' ||
        wrapChr === '*' ||
        wrapChr === '+' ||
        wrapChr === '(' ||
        wrapChr === ')') {
        return '\\' + wrapChr;
      }
      return wrapChr;
    };


    /*** Selection State Change functions ***/
    var GetFieldList = function (success, failure) {
      if (shopperAppFields) {
        success.call(null, shopperAppFields);
      } else {
        curApp.createList({
          "qDef": {"qFieldDefs": ['$Field']},
          "qInitialDataFetch": [{qTop: 0, qLeft: 0, qHeight: 9999, qWidth: 1}]
        }, function (reply) {
          shopperAppFields = {};
          if (reply.qListObject.qDataPages.length > 0) {
            $.each(reply.qListObject.qDataPages[0].qMatrix, function (key, value) {
              shopperAppFields[value[0].qText] = 1;
            });
          }
          if (reply.qInfo && reply.qInfo.qId) {
            curApp.destroySessionObject(reply.qInfo.qId);
          }
          success.call(null, shopperAppFields);
        }, failure);
      }
    };

    var SelStateToText = function (bindExp) {
      var key = "odi.";
      if ((bindExp.valState & 1) || (bindExp.valState & 2)) {
        key = key + "Selected";
      }
      if ((bindExp.valState & 4) || (bindExp.valState & 8)) {
        key = key + "Optional";
      }
      if ((bindExp.valState & 16) || (bindExp.valState & 32)) {
        key = key + "Excluded";
      }
      return translator.get(key);
    };

    var range = function (bindExp, qty) {
      if (qty > bindExp.qtyUprBnd || qty < bindExp.qtyLwrBnd) {
        // "Between {0} and {1} values of {2} must be {3}."
        return translator.get("odi.rangeConstrError", [bindExp.qtyLwrBnd, bindExp.qtyUprBnd, bindExp.fldName, SelStateToText(bindExp)]);
      }
    };

    var lwrBndOrMore = function (bindExp, qty) {
      if (qty < bindExp.qtyLwrBnd) {
        // "At least {0} values of {1} must be {2}."
        return translator.get("odi.lwrBndOrMoreConstrError", [bindExp.qtyLwrBnd, bindExp.fldName, SelStateToText(bindExp)]);
      }
    };

    var exactMatch = function (bindExp, qty) {
      if (qty !== bindExp.qtyLwrBnd) {
        // "Exactly {0} values of {1} must be {2}."
        return translator.get("odi.exactMatchConstrError", [bindExp.qtyLwrBnd, bindExp.fldName, SelStateToText(bindExp)]);
      }
    };

    var GetScriptAndBindVars = function (session, appHandle, callbackFn, onErrFnc) {
      // start by getting body of the script
      session.rpc({
        handle: appHandle,
        method: "GetScript",
        params: []
      }).then(function (scriptData) {
        var rqdFlds = {};
        var matches = [];
        var script = scriptData.result.qScript;
        // collect up the map of field names that the script is attempting to capture values for

        bindExpRegEx.lastIndex = 0;
        var result = bindExpRegEx.exec(script);
        while (result) {
          var fldName = result[2];
          var numeric = false;
          var valState = 0;
          var newMatch = {
            fldName: fldName,
            start: result.index,
            last: result.index + result[0].length
          };
          if (fldName.substr(fldName.length - 2, 2) === '_n') {   // If the fieldname ends in "_n", treat that as the signal to pull only numeric values and not wrap with quotes
            fldName = fldName.substr(0, fldName.length - 2);
            newMatch.fldName = fldName;
            numeric = true;
          }
          if (result[1].indexOf('s') >= 0) {
            if (numeric) {
              valState = valState | 2;        // include SELECTED (i.e. green) NUMERIC values
            } else {
              valState = valState | 1;        // include SELECTED (i.e. green) TEXT values
            }
          }
          if (result[1].indexOf('o') >= 0) {
            if (numeric) {
              valState = valState | 8;        // include OPTIONAL (i.e. white) NUMERIC values
            } else {
              valState = valState | 4;        // inlcude OPTIONAL (i.e. white) TEXT values
            }
          }
          if (result[1].indexOf('x') >= 0) {
            if (numeric) {
              valState = valState | 32;        // include EXCLUDED (i.e. gray) NUMERIC values
            } else {
              valState = valState | 16;      // include EXCLUDED (i.e. gray) TEXT values
            }
          }
          if (valState === 0) {                         // default (no prefix extension) case
            if (numeric) {
              valState = valState | 2;        // include SELECTED (i.e. green) NUMERIC values
            } else {
              valState = valState | 1;        // include SELECTED (i.e. green) TEXT values
            }
          }
          newMatch.valState = valState;
          // add this match to the end of the ordered list
          matches.push(newMatch);
          // push this entry into the table
          var curEntry = rqdFlds[fldName];
          if (curEntry) {
            curEntry.valState = curEntry.valState | valState;
          } else {
            rqdFlds[fldName] = {valState: valState};
          }
          // did the user supply a value Quantity spec?
          if (result.length > 3 && result[3]) {
            var qtySpec = result[3].substr(1, result[3].length - 2);
            // 4 possibilities:  M, M+, M- or M-N
            qtySpecRegEx.lastIndex = 0;
            var qsResult = qtySpecRegEx.exec(qtySpec);
            if (!qsResult) {
              onErrFnc.call(this, translator.get("odi.invalidQtySpecError", [result[0]]));
              return;
            }
            newMatch.qtyLwrBnd = parseInt(qsResult[1]);
            if (qsResult.length > 3 && qsResult[3]) {
              newMatch.qtySep = qsResult[3];
              if (qsResult.length > 4 && qsResult[4]) {  // M-N
                newMatch.qtyUprBnd = parseInt(qsResult[4]);
                if (newMatch.qtyUprBnd < newMatch.qtyLwrBnd) {
                  var t1 = newMatch.qtyLwrBnd;
                  newMatch.qtyLwrBnd = newMatch.qtyUprBnd;
                  newMatch.qtyUprBnd = t1;
                }
                newMatch.constrFnc = range;
              } else if (newMatch.qtySep === '-') {     // M-
                var t2 = newMatch.qtyLwrBnd;
                newMatch.qtyLwrBnd = 0;
                newMatch.qtyUprBnd = t2;
                newMatch.constrFnc = range;
              } else {                                // M+
                newMatch.constrFnc = lwrBndOrMore;
              }
            } else {                                  // M
              newMatch.constrFnc = exactMatch;
            }
          }
          // find next pattern occurrence
          result = bindExpRegEx.exec(script);
        }
        callbackFn.call(this, rqdFlds, matches, script);
      });
    };

    /*** Reload time functions ***/

    var GetLayout = function (session, objHandle, callbackFn) {
      session.rpc({handle: objHandle, method: "GetLayout", params: []}).then(function (response) {
        if (response.error) {
          LogError(response.error);
        }
        callbackFn.call(null, response);
      }, function (error) {
        LogError(error);
      });
    };

    var GetObject = function (session, docHandle, id, callbackFn) {
      session.rpc({
        handle: docHandle,
        method: "GetObject",
        params: {qId: id}
      }).then(function (response) {
        if (response.error) {
          LogError(response.error);
        }
        callbackFn.call(null, response);
      }, function (error) {
        LogError(error);
      });
    };

    var GetProperties = function (objHandle, callbackFn) {
      templateAppSession.rpc({
        handle: objHandle,
        method: "GetProperties",
        params: []
      }).then(function (response) {
        if (response.error) {
          LogError(response.error);
        }
        callbackFn.call(null, response);
      }, function (error) {
        LogError(error);
      });
    };

    var CopyChild = function (child, parentHandle, callbackFn) {
      var srcChildId = child.qInfo.qId;
      newAppSession.rpc({
        handle: parentHandle,
        method: "CreateChild",
        params: [{qInfo: {qId: child.qInfo.qId, qType: child.qInfo.qType}}]
      }).then(function (newChild) {
        var newChildHandle = newChild.result.qReturn.qHandle;
        GetObject(templateAppSession, templateAppHandle, srcChildId, function (oldChild) {
          GetProperties(oldChild.result.qReturn.qHandle, function (oldChildProps) {
            var childProps = oldChildProps.result.qProp;
            delete childProps.qInfo["qId"];
            newAppSession.rpc({
              handle: newChildHandle,
              method: "SetProperties",
              params: [childProps]
            }).then(function (response) {  //eslint-disable-line no-unused-vars
              callbackFn.call(null);
            });
          });
        });
      });
    };

    var CopyChildren = function (children, parentHandle, callbackFn) {
      var cIter = 0;
      if (children.length > 0) {
        for (var c in children) {
          CopyChild(children[c], parentHandle, function () {
            cIter++;
            if (cIter === children.length) {
              callbackFn.call(null);
            }
          });
        }
      }
      else {
        callbackFn.call(null);
      }
    };

    var CopyObject = function (object, parentHandle, callbackFn) {
      var srcObjId = object.name;
      newAppSession.rpc({
        handle: parentHandle,
        method: "CreateChild",
        params: [{qInfo: {qId: object.name, qType: object.type}}]
      }).then(function (newObject) {
        var newObjHandle = newObject.result.qReturn.qHandle;
        GetObject(templateAppSession, templateAppHandle, srcObjId, function (oldObject) {
          GetProperties(oldObject.result.qReturn.qHandle, function (oldObjectProps) {
            var objProps = oldObjectProps.result.qProp;
            GetLayout(templateAppSession, oldObject.result.qReturn.qHandle, function (oldObjectLayout) {
              var objLayout = oldObjectLayout.result.qLayout;
              var childList = [];
              if (objLayout.qChildList) {
                childList = objLayout.qChildList.qItems || [];
                objProps.qChildListDef = {qItems: objLayout.qChildList.qItems || []};
              }
              CopyChildren(childList, newObjHandle, function () {
                delete objProps.qInfo["qId"];
                newAppSession.rpc({
                  handle: newObjHandle,
                  method: "SetProperties",
                  params: [objProps]
                }).then(function (response) { //eslint-disable-line no-unused-vars
                  callbackFn.call(null);
                });
              })
            });
          });
        });
      });
    };

    var CopyObjects = function (sheet, parentHandle, callbackFn) {
      var oIter = 0;
      if (sheet.cells.length === 0) {
        delete sheet.qInfo["qId"];
        newAppSession.rpc({
          handle: parentHandle,
          method: "SetProperties",
          params: [sheet]
        }).then(function (response) { //eslint-disable-line no-unused-vars
          callbackFn.call(null);
        });
      } else {
        for (var o in sheet.cells) {
          LogProcess(translator.get("odi.copyingObjectsStatus"));
          CopyObject(sheet.cells[o], parentHandle, function () {
            oIter++;
            if (oIter === sheet.cells.length) {
              delete sheet.qInfo["qId"];
              newAppSession.rpc({
                handle: parentHandle,
                method: "SetProperties",
                params: [sheet]
              }).then(function (response) { //eslint-disable-line no-unused-vars
                callbackFn.call(null);
              });
            }
          });
        }
      }
    };

    var CopySheet = function (sheet, callbackFn) {
      var srcSheetId = sheet.qInfo.qId;
      newAppSession.rpc({
        handle: newAppHandle,
        method: "CreateObject",
        params: [{qInfo: sheet.qInfo}]
      }).then(function (newSheet) {
        var newSheetHandle = newSheet.result.qReturn.qHandle;
        GetObject(templateAppSession, templateAppHandle, srcSheetId, function (oldSheet) {
          GetProperties(oldSheet.result.qReturn.qHandle, function (oldSheetProps) {
            var sheetProps = oldSheetProps.result.qProp;
            //copy the objects from the sheet
            CopyObjects(sheetProps, newSheetHandle, function () {
              callbackFn.call(null);
            });
          });
        });
      });
    };

    var CopySheets = function (sheets, callbackFn) {
      var iter = 0;
      for (var i = 0; i < sheets.length; i++) {
        LogProcess(translator.get("odi.copyingSheetStatus", [iter]));
        CopySheet(sheets[i], function () {
          iter++;
          if (iter === sheets.length) {
            callbackFn.call(null);
          }
        });
      }
    };

    var GetSheetList = function (session, appHandle, callbackFn) {
      session.rpc({
        handle: appHandle,
        method: "CreateSessionObject",
        params: [{
          "qAppObjectListDef": {
            "qType": "sheet",
            "qData": {
              "title": "/qMetaDef/title",
              "description": "/qMetaDef/description",
              "thumbnail": "/thumbnail",
              "cells": "/cells",
              "rank": "/rank",
              "columns": "/columns",
              "rows": "/rows"
            }
          },
          "qInfo": {
            "qId": "SheetList",
            "qType": "SheetList"
          }
        }]
      }).then(function (response) {
        session.rpc({
          handle: response.result.qReturn.qHandle,
          method: "GetLayout",
          params: []
        }).then(function (response) {
          callbackFn.call(this, response.result.qLayout.qAppObjectList.qItems);  // sheet list is in qItems
        });
      });
    };

    var StringBuffer = function () {
      this.buffer = [];
      this.index = 0;
    };

    StringBuffer.prototype = {
      append: function (s) {
        this.buffer[this.index] = s;
        this.index += 1;
        return this;
      },

      toString: function () {
        return this.buffer.join("");
      }
    };

    var CheckDesktop = function (session) {
      var d = $.Deferred();
      if (checkedDesktop) {
        d.resolve(isDesktop);
        return d.promise();
      }
      return session.rpc({
        handle: -1,
        method: "IsDesktopMode",
        params: []
      }).then(function (response) {
        checkedDesktop = true;
        isDesktop = response.result.qReturn;
        d.resolve(isDesktop);
        return d.promise();
      });
    };

    var CountValuesForBindExpr = function (bindExp, entry) {
      var numVals = 0;
      var bitsAndData = [
        {
          bit: 1,
          size: entry.txtSelectedSize
        },
        {
          bit: 2,
          size: entry.numSelectedSize
        },
        {
          bit: 4,
          size: entry.txtOptionalSize
        },
        {
          bit: 8,
          size: entry.numOptionalSize
        },
        {
          bit: 16,
          size: entry.txtExcludedSize
        },
        {
          bit: 32,
          size: entry.numExcludedSize
        }];
      for (var i = 0; i < bitsAndData.length; i++) {
        var bAndD = bitsAndData[i];
        if (bAndD.size && (bindExp.valState & bAndD.bit)) {
          numVals = numVals + bAndD.size;
        }
      }
      return numVals;
    };

    var BuildFieldPageList = function (fldName, entry) {
      var d = $.Deferred();
      (function () {
        curApp.createList({
            qDef: {
              qFieldDefs: [fldName]
            },
            qInitialDataFetch: [{qTop: 0, qLeft: 0, qHeight: 1, qWidth: 1}]
          },
          function (reply) {
            // how many pages do we need?
            var maxValsPerPage = 10000;
            var numValues = reply.qListObject.qSize.qcy;
            var numPages = Math.floor(numValues / maxValsPerPage);
            var remainder = numValues % maxValsPerPage;
            if (remainder > 0) {
              numPages++;
            }
            var pageList = [];
            entry.pageList = pageList;
            for (var i = 0; i < numPages - 1; i++) {
              pageList.push({qTop: i * maxValsPerPage, qLeft: 0, qHeight: maxValsPerPage, qWidth: 1});
            }
            pageList.push({qTop: (numPages - 1) * maxValsPerPage, qLeft: 0, qHeight: remainder, qWidth: 1});
            if (reply.qInfo && reply.qInfo.qId) {
              curApp.destroySessionObject(reply.qInfo.qId);
            }
            return d.resolve(true);
          },
          function (error) {
            return d.reject(error);
          }
        );
      })();
      return d.promise();
    };

    var TraversePageValues = function (request, action) {
      var d = $.Deferred();
      (function () {
        curApp.createList({
            qDef: {
              qFieldDefs: [request.field]
            },
            qIncludedExcluded: false,
            qInitialDataFetch: [request.page]
          },
          function (reply) {
            $.each(reply.qListObject.qDataPages, function (p, page) {
              action.call(null, request.entry, page.qMatrix);
            });
            if (reply.qInfo && reply.qInfo.qId) {
              curApp.destroySessionObject(reply.qInfo.qId);
            }
            return d.resolve(true);
          },
          function (error) {
            return d.reject(error);
          }
        );
      })();
      return d;
    };

    var TraverseFieldValues = function (fldMap, init, action) {
      var deferreds = [];
      var allPageRequests = [];
      for (var fld in fldMap) {
        if (!fldMap.hasOwnProperty(fld) || !neededFlds.hasOwnProperty(fld)) {
          continue;
        }
        deferreds.push(BuildFieldPageList(fld, neededFlds[fld]));
      }
      return $.when.apply(this, deferreds)
        .then(function () {
          var d = $.Deferred();
          (function () {
            // now flatten the PageLists into a single array of requests in the form {entry, field, page}
            for (var f in fldMap) {
              if (!neededFlds.hasOwnProperty(f) || !neededFlds.hasOwnProperty(f)) {
                continue;
              }
              var entry = neededFlds[f];
              init.call(null, entry);
              for (var j = 0, len = entry.pageList.length; j < len; j++) {
                allPageRequests.push({field: f, entry: entry, page: entry.pageList[j]});
              }
            }
            d.resolve(true);
          })();
          return d.promise();
        })
        .then(function () {
          var d2 = $.Deferred();
          (function () {
            var d2s = [];
            for (var k = 0, len = allPageRequests.length; k < len; k++) {
              var d = TraversePageValues(allPageRequests[k], action);
              d2s.push(d);
            }
            return $.when.apply(this, d2s)
              .then(function () {
                d2.resolve(true);
              });
          })();
          return d2.promise();
        });
    };

    var InitSelectedValues = function (entry) {
      entry.txtSelected = [];
      entry.numSelected = [];
      entry.txtOptional = [];
      entry.numOptional = [];
      entry.txtExcluded = [];
      entry.numExcluded = [];
    };

    var WrapText = function (val) {
      var qChrCode;
      var repl;
      if (quoteCharacter.length === 0) {
        // use only single wrapping of quotes
        var quoteChar = "'";
        qChrCode = quoteChar.charCodeAt(0);
        repl = quoteChar + ' & chr(' + qChrCode + ') & ' + quoteChar;
        return quoteChar + val.replace(quoteChrRegEx, repl) + quoteChar;
      }

      qChrCode = quoteCharacter.charCodeAt(0);
      repl = quoteCharacter + ' & chr(' + qChrCode + ') & ' + quoteCharacter;
      return 'chr(' + qChrCode + ') & ' + quoteCharacter + val.replace(quoteChrRegEx, repl) + quoteCharacter + ' & chr(' + qChrCode + ')';
    };

    var ValueCollector = function (entry, matrix) {
      $.each(matrix, function (key, value) {
        if (value[0].qState === "S") {
          if (entry.valState & 1) {   // TEXT binding on SELECTED
            if (!entry.txtSelected) {
              entry.txtSelected = [];
            }
            entry.txtSelected.push(WrapText(value[0].qText));
          }
          if (entry.valState & 2 && value[0].qNum !== "NaN") {   // NUMERIC binidng on SELECTED}
            if (!entry.numSelected) {
              entry.numSelected = [];
            }
            entry.numSelected.push(value[0].qNum);
          }
        } else if (value[0].qState === "O") {
          if (entry.valState & 4) {                             // TEXT binding on OPTIONAL
            if (!entry.txtOptional) {
              entry.txtOptional = [];
            }
            entry.txtOptional.push(WrapText(value[0].qText));
          }
          if (entry.valState & 8 && value[0].qNum !== "NaN") {     // NUMERIC bining on OPTIONAL
            if (!entry.numOptional) {
              entry.numOptional = [];
            }
            entry.numOptional.push(value[0].qNum);
          }
        } else if (value[0].qState === "X") {
          if (entry.valState & 16) {                              // TEXT binding on EXCLUDED
            if (!entry.txtExcluded) {
              entry.txtExcluded = [];
            }
            entry.txtExcluded.push(WrapText(value[0].qText));
          }
          if (entry.valState & 32 && value[0].qNum !== "NaN") {    // NUMERIC binding on EXCLUDED
            if (!entry.numExcluded) {
              entry.numExcluded = [];
            }
            entry.numExcluded.push(value[0].qNum);
          }
        }
      });
    };

    var InitSelectionCounts = function (entry) {
      entry.txtSelectedSize = 0;
      entry.numSelectedSize = 0;
      entry.txtOptionalSize = 0;
      entry.numOptionalSize = 0;
      entry.txtExcludedSize = 0;
      entry.numExcludedSize = 0;
    };

    var SelectionCounter = function (entry, matrix) {
      $.each(matrix, function (key, value) {
        if (value[0].qState === "S") {
          if (entry.valState & 1) {   // TEXT binding on SELECTED
            if (!entry.txtSelectedSize) {
              entry.txtSelectedSize = 0;
            }
            entry.txtSelectedSize++;
          }
          if (entry.valState & 2 && value[0].qNum !== "NaN") {   // NUMERIC binidng on SELECTED}
            if (!entry.numSelectedSize) {
              entry.numSelectedSize = 0;
            }
            entry.numSelectedSize++;
          }
        } else if (value[0].qState === "O") {
          if (entry.valState & 4) {                             // TEXT binding on OPTIONAL
            if (!entry.txtOptionalSize) {
              entry.txtOptionalSize = 0;
            }
            entry.txtOptionalSize++;
          }
          if (entry.valState & 8 && value[0].qNum !== "NaN") {     // NUMERIC bining on OPTIONAL
            if (!entry.numOptionalSize) {
              entry.numOptionalSize = 0;
            }
            entry.numOptionalSize++;
          }
        } else if (value[0].qState === "X") {
          if (entry.valState & 16) {                              // TEXT binding on EXCLUDED
            if (!entry.txtExcludedSize) {
              entry.txtExcludedSize = 0;
            }
            entry.txtExcludedSize++;
          }
          if (entry.valState & 32 && value[0].qNum !== "NaN") {    // NUMERIC binding on EXCLUDED
            if (!entry.numExcludedSize) {
              entry.numExcludedSize = 0;
            }
            entry.numExcludedSize++;
          }
        }
      });
    };

    var GetValCountsForConstrFields = function (fldMap) {
      return TraverseFieldValues(fldMap, InitSelectionCounts, SelectionCounter);
    };

    var GetValuesForFields = function (fldMap) {
      return TraverseFieldValues(fldMap, InitSelectedValues, ValueCollector);
    };

    var BuildExpansion = function (match, entry) {
      var vals = [];
      var bitsAndData = [
        {
          bit: 1,
          data: entry.txtSelected
        },
        {
          bit: 2,
          data: entry.numSelected
        },
        {
          bit: 4,
          data: entry.txtOptional
        },
        {
          bit: 8,
          data: entry.numOptional
        },
        {
          bit: 16,
          data: entry.txtExcluded
        },
        {
          bit: 32,
          data: entry.numExcluded
        }];
      for (var i = 0; i < bitsAndData.length; i++) {
        var bAndD = bitsAndData[i];
        if (bAndD.data && match.valState & bAndD.bit) {
          vals.push.apply(vals, bAndD.data);
        }
      }
      return vals;
    };

    var SetScript = function () {
      return GetValuesForFields(neededFlds)
        .then(function () {
          var delimChrCode = delimiter.charCodeAt(0);
          var scrBuf = new StringBuffer();
          var priorLast = 0;
          // Assemble the script by substituting in the requested field values at each bind variable location in the template
          // in the exact order in which the bind variables occur in the script
          for (var i = 0; i < matchesInPosOrder.length; i++) {
            var head;
            var match = matchesInPosOrder[i];
            if (i === 0) {
              head = templAppScript.substr(0, match.start);
            } else {
              head = templAppScript.substr(priorLast, match.start - priorLast);
            }
            priorLast = match.last;
            scrBuf.append(head);
            var valList = BuildExpansion(match, neededFlds[match.fldName]);
            if (valList.length === 0) {
              scrBuf.append("''");  // No Data for this field, use empty string
            } else {
              scrBuf.append(valList.join(' & chr(' + delimChrCode + ') & '));
            }
          }
          scrBuf.append(templAppScript.substr(priorLast, templAppScript.length - priorLast));
          onDemandScript = scrBuf.toString();
        });
    };

    var SaveNewApp = function () {
      LogProcess(translator.get("odi.savingNewApp", [newAppName]));
      newAppSession.rpc({handle: newAppHandle, method: "DoSave", params: []}).then(function (response) { //eslint-disable-line no-unused-vars
        if (scope.view !== "error") {
          scope.view = "done";
          var url = "http";
          var options = scope.backendApi.model.session.options;
          url += (options.isSecure === true ? "s://" : "://");
          url += options.host;
          url += (options.port != null ? ":" + options.port : "");
          url += options.prefix;
          url += "sense/app/";
          url += newAppId;
          if (targetAppSheetId) {
            url += "/sheet/" + targetAppSheetId + "/state/analysis";
          }
          scope.newAppUrl = url;

          // delete the oldest prior version of the generated app
          if (oldestPriorOddAppId) {
            newAppSession.rpc({
              handle: -1,
              method: "DeleteApp",
              params: [oldestPriorOddAppId]
            }).then(function (response) {
              if (!response.result || response.result.qSuccess !== true) {
                LogError(translator.get("odi.deleteOdAppFailed"));
                newAppSession = CloseSession(newAppSession);
              } else {
                sharedSession = CloseSession(sharedSession);
              }
              scope.$apply();
            }, function (reject) {  //eslint-disable-line no-unused-vars
              sharedSession = CloseSession(sharedSession);
              newAppSession = CloseSession(newAppSession);
              scope.$apply();
            });
          } else {
            sharedSession = CloseSession(sharedSession);
            newAppSession = CloseSession(newAppSession);
            scope.$apply();
          }
        }
      });
    };

    var AppendProgMsg = function (text) {
      if (text === "") {
        return;
      }
      // see if this message is all numbers and comma in a sequence
      var curMatch = text.match(numRegExp);
      var lastPos = scope.progmsgs.length - 1;
      // is the current message a number?
      if (curMatch) {
        // was the prior written message a number?
        if (lastProgWasNumber && scope.progmsgs[lastPos]) {
          // then replace the text of the last message with the text of this new number
          scope.progmsgs[lastPos].text = text;
        } else {
          scope.progmsgs.push({id: scope.progmsgs.length, text: text});
          lastProgWasNumber = true;
        }
      } else if (lastProgWasNumber || scope.progmsgs.length === 0 || scope.progmsgs[lastPos].text !== text) {
        lastProgWasNumber = false;
        scope.progmsgs.push({id: scope.progmsgs.length, text: text});
      }
      scope.$apply();
      // console.log(text);       // DEBUG-only
    };

    var MonitorProgress = function (doTransient) {
      newAppSession.rpc({handle: -1, method: "GetProgress", params: [0]}).then(function (reloadProgress) {
        if (reloadProgress.result.qProgressData.qPersistentProgressMessages) {
          for (var i = 0; i < reloadProgress.result.qProgressData.qPersistentProgressMessages.length; i++) {
            switch (reloadProgress.result.qProgressData.qPersistentProgressMessages[i].qMessageCode) {
              case 10:
              case 7:
                scope.view = "error";
                var msgParams = reloadProgress.result.qProgressData.qPersistentProgressMessages[i].qMessageParameters;
                var len = msgParams.length;
                for (var j = 0; j < len; j++) {
                  AppendProgMsg(msgParams[j]);
                }
                continueMonitoring = false;
                return;

              default:
                if (reloadProgress.result.qProgressData.qPersistentProgressMessages[i].qMessageParameters.length > 0) {
                  AppendProgMsg(reloadProgress.result.qProgressData.qPersistentProgressMessages[i].qMessageParameters[0]);
                }
                break;
            }
          }
          $(".odag-progmsgs").map(function () {
            $(this).scrollTop(10000000);  // scroll to the bottom of the div
          });
        }
        if (doTransient) {
          if (reloadProgress.result.qProgressData.qTransientProgressMessage &&
            reloadProgress.result.qProgressData.qTransientProgressMessage.qMessageParameters) {
            for (var k = 0; k < reloadProgress.result.qProgressData.qTransientProgressMessage.qMessageParameters.length; k++) {
              AppendProgMsg(reloadProgress.result.qProgressData.qTransientProgressMessage.qMessageParameters[k]);
            }
            $(".odag-progmsgs").map(function () {
              $(this).scrollTop(10000000);  // scroll to the bottom of the div
            });
          }
          if (continueMonitoring) {
            setTimeout(function () {
              MonitorProgress(true);
            }, 100);
          }
        } else if (reloadProgress.result.qProgressData.qFinished === true) {
          continueMonitoring = false;
          SaveNewApp();
        }
      });
    };

    var Reload = function () {
      if (scope.cancelPending) {
        LogError(translator.get("odi.reloadCancelled"));
      } else {
        LogProcess(translator.get("odi.loadingDataStatus", [newAppName]));
        continueMonitoring = true;
        lastProgWasNumber = false;
        newAppSession.rpc({handle: newAppHandle, method: "DoReload", params: []}).then(function (response) {
          if (!response.result.qReturn) {
            scope.view = "error";
            scope.lastError = translator.get("odi.dataLoadFailed");
          }
          continueMonitoring = false;
          MonitorProgress(false);
          scope.$apply();
        });
        // Now monitor the progress of the Reload and save the app once it's done
        MonitorProgress(true);
      }
    };

    var BindAndReload = function () {
      LogProcess(translator.get("odi.bindingDataStatus", [newAppName]));
      SetScript()
        .then(function () {
          newAppSession.rpc({handle: newAppHandle, method: "SetScript", params: [onDemandScript]})
            .then(function (response) {  //eslint-disable-line no-unused-vars
              Reload();
              scope.$apply();
            }, function (error) {
              LogError(error);
              scope.$apply();
            });
        }, function (error) {
          LogError(error);
          scope.$apply();
        });
    };

    return {
      Init: function (controller_scope, controller_layout, controller_translator) {
        scope = controller_scope;
        layout = controller_layout;
        translator = controller_translator;

        if (typeof layout.advanced.quoteCharacter === 'string') {
          if (layout.advanced.quoteCharacter.toLocaleLowerCase() === 'none') {
            quoteCharacter = '';
            quoteChrRegEx = new RegExp("'", "gim");
          } else if (layout.advanced.quoteCharacter.length > 0) {
            quoteCharacter = layout.advanced.quoteCharacter.substr(0, 1);
            quoteChrRegEx = new RegExp(EscapeRegExSpChr(quoteCharacter), "gim");
          } else {
            quoteCharacter = "'";
            quoteChrRegEx = new RegExp(EscapeRegExSpChr(quoteCharacter), "gim");
          }
        } else {
          quoteCharacter = "'";
          quoteChrRegEx = new RegExp(EscapeRegExSpChr(quoteCharacter), "gim");
        }

        if (typeof layout.advanced.delimiter === 'string') {
          if (layout.advanced.delimiter.toLocaleLowerCase() === 'none') {
            delimiter = '';
          } else if (layout.advanced.delimiter.length > 0) {
            delimiter = layout.advanced.delimiter.substr(0, 1);
          } else {
            delimiter = ",";
          }
        } else {
          delimiter = ",";
        }
      },

      // make sure there is an overlap of fields between the shoppering cart's fields and the bind variabls in the template app's script
      CheckBindings: function (targetAppNameChanged, callbackFn) {
        scope.checkBindError = false;
        if (!targetAppNameChanged) {
          // if app name did not change, simply return the prior state
          callbackFn.call(null);
        } else {
          scope.matchExpr = translator.get("odi.matchExp", [0, 0]);
          // get the list of fields from the shopper app
          GetFieldList(function (shopAppFlds) {
            // need to identify the most recent template app
            sharedSession = ODISession.open(scope);
            CheckDesktop(sharedSession)
              .then(function (onDesktop) {
                if (onDesktop) {
                  sharedSession = CloseSession(sharedSession);
                  scope.isDesktop = true;
                  callbackFn.call(null);
                } else {
                  sharedSession.rpc({handle: -1, method: "GetDocList", params: []}).then(function (response) {
                    sharedSession = CloseSession(sharedSession);
                    var arrayFound = response.result.qDocList.filter(function (item) {
                      return (item.qDocName === scope.targetApp);
                    });
                    if (arrayFound.length === 0) {   // no matching template app?
                      scope.invTemplAppName = true;
                      scope.noBindings = false;
                      callbackFn.call(null);
                    } else {                          // find the most recent template app
                      scope.invTemplAppName = false;
                      templateAppId = arrayFound[0].qDocId;
                      var newest = Date.parse(arrayFound[0].qMeta.modifiedDate);
                      for (var j = 1; j < arrayFound.length; j++) {
                        var curOdTs = Date.parse(arrayFound[j].qMeta.modifiedDate);
                        if (curOdTs > newest) {
                          newest = curOdTs;
                          templateAppId = arrayFound[j].qDocId;
                        }
                      }
                      // start fresh session to open the template app to get the script and bind variables
                      var tmpSession = ODISession.open(scope, templateAppId);
                      tmpSession.rpc({            // open the template app
                        handle: -1,
                        method: "OpenDoc",
                        params: [templateAppId]
                      }).then(function (response) {
                        GetScriptAndBindVars(tmpSession, response.result.qReturn.qHandle, function (rqdFlds, matches, script) {
                          // make sure at least one bind variable from script is available for this app
                          var matchCnt = 0;
                          var totalPossible = 0;
                          $.each(rqdFlds, function (f, d) {  //eslint-disable-line no-unused-vars
                            totalPossible++;
                            if (shopAppFlds[f]) {
                              matchCnt++;
                            }
                          });
                          scope.matchExpr = translator.get("odi.matchExp", [matchCnt, totalPossible]);
                          var result = true;
                          if (matchCnt > 0) {
                            result = false;
                            // cache the script and the bind information
                            neededFlds = rqdFlds;
                            matchesInPosOrder = matches;
                          }
                          templAppScript = script;
                          tmpSession = CloseSession(tmpSession);
                          scope.noBindings = result;
                          callbackFn.call(null);
                        }, function (err) {
                          tmpSession = CloseSession(tmpSession);
                          scope.checkBindError = true;
                          scope.noBindings = false;
                          scope.error = err;
                          callbackFn.call(null);
                        });
                      }, function (reject) {  //eslint-disable-line no-unused-vars
                        tmpSession = CloseSession(tmpSession);
                        scope.checkBindError = true;
                        scope.error = translator.get("odi.templateAppNotFound", [templateAppId]);
                        scope.noBindings = false;
                        callbackFn.call(null);
                      });
                    }
                  }, function (reject) {  //eslint-disable-line no-unused-vars
                    sharedSession = CloseSession(sharedSession);
                    scope.checkBindError = true;
                    scope.error = translator.get("odi.getDocListFailed");
                    callbackFn.call(null);
                  });
                }
              });
          }, function (error) {
            scope.checkBindError = true;
            scope.error = error;
            callbackFn.call(null);
          });
        }
      },

      // make sure user has made all necessary minimal secltions according to the selection quantity constraints (if any)
      CheckSelQtyConstraints: function () {
        var d = $.Deferred();
        var fldsWithQtyExp = {};
        var numFlds = 0;
        // construct the list of needed fields from the matches that have selection quantity constraints
        for (var i = 0; i < matchesInPosOrder.length; i++) {
          var bindExp = matchesInPosOrder[i];
          if (bindExp.constrFnc) {
            if (!fldsWithQtyExp.hasOwnProperty(bindExp.fldName)) {
              fldsWithQtyExp[bindExp.fldName] = 1;
              numFlds++;
            }
          }
        }
        if (numFlds === 0) {
          d.resolve(true);    // no work to do here since there are no selection quantity constraints
          return d;
        }
        return GetValCountsForConstrFields(fldsWithQtyExp)
          .then(function () {
            scope.qtyConstrViolations = [];
            for (var i = 0; i < matchesInPosOrder.length; i++) {
              var bindExp = matchesInPosOrder[i];
              if (!fldsWithQtyExp.hasOwnProperty(bindExp.fldName)) {
                continue;
              }
              var numVals = CountValuesForBindExpr(bindExp, neededFlds[bindExp.fldName]);
              // count the number of
              if (bindExp.constrFnc) {
                var constrErr = bindExp.constrFnc(bindExp, numVals);
                if (constrErr) {
                  scope.qtyConstrViolations.push(constrErr);
                }
              }
            }
          });
      },

      CreateApp: function () {
        var appName = "";

        LogProcess(translator.get("odi.createOdDataRequestStatus"));

        targetAppSheetId = null;
        sharedSession = ODISession.open(scope);
        //create the new App
        sharedSession.rpc({handle: -1, method: "GetAuthenticatedUser", params: []}).then(function (response) {
          if (scope.genAppName) {
            appName = scope.genAppName;
          } else {
            appName = scope.targetApp + '_' + response.result.qReturn.split(";")[1].split("=")[1];
          }
          newAppName = appName;

          if (!layout.openAppBtnLbl) {
            scope.openAppBtnLbl = translator.get("odi.openAppBtnLbl", [newAppName]);
          }
          // find template app:
          sharedSession.rpc({handle: -1, method: "GetDocList", params: []}).then(function (response) {
            // Find oldest prior on-demand app with same name
            var matchedPriorOdds = response.result.qDocList.filter(function (item) {
              return (item.qDocName === appName);
            });
            oldestPriorOddAppId = null;
            // if we already have the limit on the number of sub-apps, find the oldest one and target it for cleanup
            if (matchedPriorOdds.length >= scope.maxGenerated) {
              oldestPriorOddAppId = matchedPriorOdds[0].qDocId;
              var oldest = Date.parse(matchedPriorOdds[0].qMeta.modifiedDate);
              for (var i = 1; i < matchedPriorOdds.length; i++) {
                var curTs = Date.parse(matchedPriorOdds[i].qMeta.modifiedDate);
                if (curTs < oldest) {
                  oldest = curTs;
                  oldestPriorOddAppId = matchedPriorOdds[i].qDocId;
                }
              }
            }
            // start a fresh session for accessing the On-Demand Template App's sheet content
            templateAppSession = ODISession.open(scope, templateAppId);
            templateAppSession.rpc({            // open the template app
              handle: -1,
              method: "OpenDoc",
              params: [templateAppId]
            }).then(function (response) {
              templateAppHandle = response.result.qReturn.qHandle;
              // get the thumbnail image of the template app
              templateAppSession.rpc({
                handle: templateAppHandle,
                method: "GetAppProperties",
                params: []
              }).then(function (response) {
                var templAppProps = response.result.qProp;
                // now create a new app and copy the contents of the template app into it
                sharedSession.rpc({handle: -1, method: "CreateApp", params: [appName]}).then(function (response) {
                  if (response.result && response.result.qSuccess === true) {
                    newAppId = response.result.qAppId;
                    sharedSession.rpc({
                      handle: -1,
                      method: "CopyApp",
                      params: [newAppId, templateAppId, []]
                    }).then(function (response) {   //eslint-disable-line no-unused-vars
                      //open the new app and but first setup a 2nd socket for working with the new app
                      newAppSession = ODISession.open(scope, newAppId);
                      newAppSession.rpc({
                        handle: -1,
                        method: "OpenDoc",
                        params: [newAppId]
                      }).then(function (response) {
                          newAppHandle = response.result.qReturn.qHandle;
                          // Pre Sense 2.3, CopyApp would not copy sheet contents so need to test
                          // whether created app actually contains sheets already (v2.3+) or still
                          // needs them copied
                          GetSheetList(templateAppSession, templateAppHandle, function (sheets) {
                            var srcSheets = sheets;
                            var sheetsToCopy = [];
                            GetSheetList(newAppSession, newAppHandle, function (tarSheets) {
                              // see if any sheet from the src is missing from the target
                              $.each(srcSheets, function (k, ssh) {
                                if (ssh.qInfo.qId === scope.targetAppSheet || ssh.qData.title === scope.targetAppSheet) {
                                  targetAppSheetId = ssh.qInfo.qId;
                                }
                                // see if this sheet is missing from target, include it in the copy list if so
                                var foundTarget = false;
                                $.each(tarSheets, function (m, tsh) {
                                  if (tsh.qInfo.qId === ssh.qInfo.qId) {
                                    foundTarget = true;
                                  }
                                });
                                if (!foundTarget) {
                                  sheetsToCopy.push(ssh);
                                }
                              });
                              if (templAppProps.qThumbnail && templAppProps.qThumbnail.qUrl) {
                                templAppProps.qTitle = appName;
                                newAppSession.rpc(
                                  {
                                    handle: newAppHandle,
                                    method: "SetAppProperties",
                                    params: [templAppProps]
                                  }).then(function (response) {  //eslint-disable-line no-unused-vars
                                  if (sheetsToCopy.length > 0) {
                                    CopySheets(sheetsToCopy, function () {
                                      templateAppSession = CloseSession(templateAppSession);
                                      BindAndReload();
                                    });
                                  } else {
                                    templateAppSession = CloseSession(templateAppSession);
                                    BindAndReload();
                                  }
                                }, function (reject) {  //eslint-disable-line no-unused-vars
                                  if (sheetsToCopy.length > 0) {
                                    CopySheets(sheetsToCopy, function () {
                                      templateAppSession = CloseSession(templateAppSession);
                                      BindAndReload();
                                    } /*  TODO reject handler ?? */);
                                  } else {
                                    templateAppSession = CloseSession(templateAppSession);
                                    BindAndReload();
                                  }
                                });
                              } else if (sheetsToCopy.length > 0) {
                                CopySheets(sheetsToCopy, function () {
                                  templateAppSession = CloseSession(templateAppSession);
                                  BindAndReload();
                                } /*  TODO reject handler ?? */);
                              } else {
                                templateAppSession = CloseSession(templateAppSession);
                                BindAndReload();
                              }
                            } /*  TODO reject handler ?? */);
                          }, function (reject) { //eslint-disable-line no-unused-vars
                            LogError(translator.get("odi.getTmplAppSheetListFailed"));
                            scope.$apply();
                          });
                        },
                        function (reject) { //eslint-disable-line no-unused-vars
                          LogError(translator.get("odi.odAppOpenFailed"));
                          scope.$apply();
                        });
                    });
                  } else {
                    LogError(translator.get("odi.odAppCreateFailed"));
                    scope.$apply();
                  }
                });
              });
            }, function (reject) {  //eslint-disable-line no-unused-vars
              LogError(translator.get("odi.odTemplAppOpenFailed"));
              scope.$apply();
            });
          }, function (reject) {  //eslint-disable-line no-unused-vars
            LogError(translator.get("odi.getDocListFailed"));
            scope.$apply();
          });
        }, function (reject) {  //eslint-disable-line no-unused-vars
          LogError(translator.get("odi.getAuthUserFailed"));
          scope.$apply();
        });
      },

      CancelReload: function () {
        scope.cancelPending = true;
        if (newAppSession && continueMonitoring) {
          LogProcess(translator.get("odi.cancelingReload"));
          newAppSession.rpc({handle: -1, method: "CancelReload", params: []}).then(function (response) {  //eslint-disable-line no-unused-vars
            scope.$apply();
          });
        }
      }
    }
  }

  return {
    createAppBuilder : createAppBuilder
  };
});
