define( [
  "./xltns/propxltns"
], function (propXltns) {

  function format ( trans, args ) {
    trans = trans || "";
    args = args || [];

    if ( typeof args === "string" || typeof args === "number" ) {
      args = [args];
    }

    return trans.replace( /\{(\d+)\}/g, function ( match, number ) {
      return typeof args[number] !== "undefined" ?
        args[number] :
        match;
    } );
  }

  var lang = this.navigator.userLanguage || this.navigator.language || 'en-US';
  var propDictionary = propXltns[lang];
  if(!propDictionary) {
    propDictionary = propXltns['en-US'];
  }

  return {
    get:  function (key, args) {
            var xltn = key;
            if(propDictionary) {
              xltn = propDictionary[key];
              if(xltn === "undefined") {
                xltn = key;
              } else if(args !== undefined) {
                xltn = format(xltn, args);
              }
            }
            return xltn;
          }

  };
});
