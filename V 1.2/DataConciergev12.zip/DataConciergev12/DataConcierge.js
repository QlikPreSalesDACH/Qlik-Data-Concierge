//  ------------------------------------------------------------------------------------- //
//                                                                                       							   //
//                              Configuration-Dialog                                     					   //
//                                                                                        							   //
//  ------------------------------------------------------------------------------------- //

var applicationid = "<APPID>";     											// Please insert the APPID from Qlik Data Concierge 1.2.qvf here
var applicationfolder = "DataConciergev12";                     		// Please insert the FOLDERNAME (e.g. DataConciergev12)
var vsiteurl = "http://<SERVERNAME>/sense/app/"                // URL to Qlik Sense Apps (e.g. http(s)://<SERVER>/sense/app/)
var vNamespace = "Query_";                                      		    // First word for namestring for the appname (e.g. Query_)

//  ------------------------------------------------------------------------------------- //

var rootPath = window.location.hostname;
var portUrl = "80";

if (window.location.port == "") {
    if ("https:" == window.location.protocol)
        portUrl = "443";
    else {
        portUrl = "80";
    }
}
else
    portUrl = window.location.port;

var pathRoot = "//localhost:4848/extensions/";
if (portUrl != "4848")
    pathRoot = "//" + rootPath + ":" + portUrl + "/resources/";

var config = {                                           
    host: window.location.hostname,
    prefix: "/",
    port: window.location.port,
    isSecure: window.location.protocol === "https:"
};

require.config({
    baseUrl: (config.isSecure ? "https://" : "http://") + config.host + (config.port ? ":" + config.port : "") + config.prefix + "resources",
    paths: { app: (config.isSecure ? "https://" : "http://") + config.host + (config.port ? ":" + config.port : "") }
});

require([
    "js/qlik",
    "jquery",
    applicationfolder + "/js/bootstrap.min",
    applicationfolder + "/js/bootstrap-select.min",
    applicationfolder + "/js/qsocks.bundle",
    applicationfolder + "/js/bootstrap-notify.min",
    applicationfolder + "/js/jquery.cookie",
],

function (qlik, $, Selectpicker, qsocks) {

    // Create Variables for Application
    var vInfoprovider = "";
    var vBexQueryDes = "";
    var vBexQuery = "";
    var vLoad = "";
    var vDimensions = "";
    var vMeasures = "";
    var vUnit = "";
    var vBexVariable = "";
    var vVariable = "";
    var vVarNAM = "";
    var table = "";
    var arr = [];
    var arrr = [];
    var vvariabletype = "";
    var vselecttype = "";
    var namearr = [];
    var vVarLOWValue = "";
    var LOW = "";
    var HIGH = "";
    var vVariableCounter = "";
    var num = "";
    var vVarNAMCounter1 = 0;
    var vVarNAMCounter2 = 0;
    var vVarNAMCounter3 = 0;
    var vScript = "";
    var vDataConnection = "";
    var targetapp = "";
    var vSwitch = 0;
    var vAppMeasures = [];
    var vAppDimensions = [];
    var vSELDEFLOW = [];
    var vSELDEFHIGH = [];

    var CheckDim = 0;
    var CheckMes = 0;
    var CheckInfo = 0;
    var CheckQuery = 0;
    var CheckConn = 0;
    var CheckMod = 0;

    var reloaded = null;

    // APP UI functions
    function AppUi(app) {
        var me = this;
        this.app = app;
        app.global.isPersonalMode(function (reply) {
            me.isPersonalMode = reply.qReturn;
        });
        app.getList("BookmarkList", function (reply) {
            var str = "";
            reply.qBookmarkList.qItems.forEach(function (value) {
                if (value.qData.title) {
                    str += '<li><a class="linkstyle" href="#" data-id="' + value.qInfo.qId + '">' + value.qData.title + '</a></li>';
                }
            });
            str += '<li role="separator" class="divider"></li><li><a href="#" data-cmd="create"><b>Create Bookmark</b></a></li>';
            $('#qbmlist').html(str).find('a').on('click', function () {
                var id = $(this).data('id');
                if (id) {
                    app.bookmark.apply(id);
                } else {
                    var cmd = $(this).data('cmd');
                    if (cmd === "create") {
                        $('#createBmModal').modal();
                    }
                }
            });
        });
    }
    $("[data-qcmd]").on('click', function () {
        var $element = $(this);
        switch ($element.data('qcmd')) {
            //app level commands
            case 'createBm':
                var title = $("#bmtitle").val(), desc = $("#bmdesc").val();
                app.bookmark.create(title, desc);
                $('#createBmModal').modal('hide');
                break;
        }
    });

    // Infoprovider to Variable
    function showDataInfo(reply, app) {
        $.each(reply.qListObject.qDataPages[0].qMatrix, function (key, value) {
            if (typeof value[0].qText !== 'undefined' && value[0].qState == 'S') {
                vInfoprovider = value[0].qText
            } else {
                if (typeof value[0].qText !== 'undefined' && value[0].qState == 'O') {
                    vInfoprovider = value[0].qText
                }
            }
        });
    }

    // BexQuery to Variable
    function showDataBex(reply, app) {
        $.each(reply.qListObject.qDataPages[0].qMatrix, function (key, value) {
            if (typeof value[0].qText !== 'undefined' && value[0].qState == 'S') {
                vBexQuery = value[0].qText
            } else {
                if (typeof value[0].qText !== 'undefined' && value[0].qState == 'O') {
                    vBexQuery = value[0].qText
                }
            }
        });
    }

    // BexQueryDes to Variable
    function showDataBexDes(reply, app) {
        $.each(reply.qListObject.qDataPages[0].qMatrix, function (key, value) {
            if (typeof value[0].qText !== 'undefined' && value[0].qState == 'S') {
                vBexQueryDes = value[0].qText
            } else {
                if (typeof value[0].qText !== 'undefined' && value[0].qState == 'O') {
                    vBexQueryDes = value[0].qText
                }
            }
        });
    }

    // Get Variables from APP
    function showVariables(reply) {
        vLoad = reply.Load;
        vDimensions = reply.Dimensions;
        vMeasures = reply.Measures;
        vUnit = reply.Unit;
    };

    //GET BexVariables from APP
    function showBexVariables(reply, app) {
        $.each(reply.qListObject.qDataPages[0].qMatrix, function (key, value) {
            if (typeof value[0].qText !== 'undefined' && value[0].qState == 'O') {
                vBexVariable = value[0].qText;
                //console.log(vBexVariable);
            }
        });
    }

    //GET VAR_NAM from APP
    function getVar_NAM(reply, app) {
        namearr = [];
        var vVarNAMCounter1 = 0;
        var vVarNAMCounter2 = 0;
        var vVarNAMCounter3 = 0;
        $('#SetVariables').empty();
        table += '<table id="Variabletable" border=0><thead style="text-align: center;vertical-align: middle;"><tr><th style="width:50px;">I/O</th><th>Name</th><th>Sign</th><th>Option</th><th>Low</th><th>High</th><th style="display:none;">Technical Name</th></tr></thead><tbody>';
        $.each(reply.qListObject.qDataPages[0].qMatrix, function (key, value) {
            if (value[0].qText !== 'undefined' && value[0].qState == 'O') {
                vVarNAM = value[0].qText;
                vVarNAMCounter1++;
                table += '<tr id="ROW' + vVarNAMCounter1 + '">';
                table += '<td  style="text-align: center;vertical-align: middle;"><input id="Check' + vVarNAMCounter1 + '"type="checkbox" value="" style="margin:5px;"></td>'
                table += '<td><span class="input-group" id="Name' + vVarNAMCounter1 + '"></span></td>';
                table += '<td><select id="Sign' + vVarNAMCounter1 + '" class="selectpicker show-menu-arrow" data-size="10" title="nothing selected" data-style="btn-default" style="display: none;"><option>Include</option><option>Exclude</option></td>'
                table += '<td><select id="Option' + vVarNAMCounter1 + '" class="selectpicker show-menu-arrow" data-size="10" title="nothing selected" data-style="btn-default" style="display: none;"><option value="=">=</option><option value="<>"><></option><option value="<"><</option><option value=">">></option><option value="<="><=</option><option value=">=">>=</option><option value="Between">Between</option></td>'

                table += '<td><select id="LOWSEL' + vVarNAMCounter1 + '" class="selectpicker show-menu-arrow" data-size="10" title="nothing selected" data-live-search="true" data-style="btn-default" style="display: none;"></td>'
                table += '<td><select id="HIGHSEL' + vVarNAMCounter1 + '" class="selectpicker show-menu-arrow" data-size="10" title="nothing selected" data-live-search="true" data-style="btn-default" style="display: none;"></td>'
                table += '<td style="display:none;"><span id="Tname' + vVarNAMCounter1 + '" class="input-group" id="basic-addon1" style="display:none;"></span></td>';

                app.createGenericObject({
                    LOWEXPRESSION: { qStringExpression: "=concat(distinct {<[DESCRIPTION_VARIABLE] = {" + "'" + vVarNAM + "'" + "}>} '<option data-subtext=' & MEM_NAM & '>' & MEM_CAP &'</option>','~')" },
                    COUNTER: { qStringExpression: "=count(distinct{<[DESCRIPTION_VARIABLE] = {" + "'" + vVarNAM + "'" + "}>}MEM_CAP)" },
                    TECHNAMEVAR: { qStringExpression: "=concat(distinct{<[DESCRIPTION_VARIABLE] = {" + "'" + vVarNAM + "'" + "}>}VAR_NAM_FINAL)" },
                    MANDATORY: { qStringExpression: "=concat(distinct{<[DESCRIPTION_VARIABLE] = {" + "'" + vVarNAM + "'" + "}>}VAR_ENTRY_TYPE)" },
                    SELECTTYPE: { qStringExpression: "=concat(distinct{<[DESCRIPTION_VARIABLE] = {" + "'" + vVarNAM + "'" + "}>}VAR_SELC_TYPE)" },
                    DEFAULT_LOW: { qStringExpression: "=concat(distinct{<[DESCRIPTION_VARIABLE] = {" + "'" + vVarNAM + "'" + "}>}DEFAULT_LOW)" },
                    DEFAULT_HIGH: { qStringExpression: "=concat(distinct{<[DESCRIPTION_VARIABLE] = {" + "'" + vVarNAM + "'" + "}>}DEFAULT_HIGH)" },
                    NAME: { qStringExpression: "=concat(distinct {<[DESCRIPTION_VARIABLE] = {" + "'" + vVarNAM + "'" + "}>} [DESCRIPTION_VARIABLE],'~')" },
                }, Stringtoli);

                function Stringtoli(reply) {
                    vVarNAMCounter2++;
                    var arr = reply.LOWEXPRESSION.split("~");
                    var cList1 = $('#LOWSEL' + vVarNAMCounter2);
                    var cList2 = $('#HIGHSEL' + vVarNAMCounter2);
                    $.each(arr, function (i) {
                        var li = $(arr[i]).appendTo(cList1);
                        var li = $(arr[i]).appendTo(cList2);
                        
                    });
                    if (reply.DEFAULT_LOW != '') {
                        $('#LOWSEL' + vVarNAMCounter2).append($("<option></option>").attr("data-subtext", reply.DEFAULT_LOW).text(reply.DEFAULT_LOW));
                    }
                    if (reply.DEFAULT_HIGH != '') {
                        $('#HIGHSEL' + vVarNAMCounter2).append($("<option></option>").attr("data-subtext", reply.DEFAULT_HIGH).text(reply.DEFAULT_HIGH));
                    }
                    vVarNAMCounter3++;
                    arrr = reply.TECHNAMEVAR;
                    vvariabletype = reply.MANDATORY;
                    vselecttype = reply.SELECTTYPE;
                    $('#ROW' + vVarNAMCounter3).addClass('vartype' + vvariabletype);
                    if (vvariabletype == 1 || vvariabletype == 2) {
                        $('#Check' + vVarNAMCounter3).addClass('MANDATORY');
                    }

                    switch (vselecttype) {
                        case '1':
                            $('#HIGHSEL' + vVarNAMCounter3).attr('disabled', 'disabled');
                            $('#Option' + vVarNAMCounter3 + " option[value='Between']").remove();
                            $('#Option' + vVarNAMCounter3 + " option[value='<>']").remove();
                            $('#Option' + vVarNAMCounter3 + " option[value='<']").remove();
                            $('#Option' + vVarNAMCounter3 + " option[value='>']").remove();
                            $('#Option' + vVarNAMCounter3 + " option[value='<=']").remove();
                            $('#Option' + vVarNAMCounter3 + " option[value='>=']").remove();
                            break;

                        case '2':
                            $('#Option' + vVarNAMCounter3 + " option[value='<>']").remove();
                            $('#Option' + vVarNAMCounter3 + " option[value='<']").remove();
                            $('#Option' + vVarNAMCounter3 + " option[value='>']").remove();
                            $('#Option' + vVarNAMCounter3 + " option[value='<=']").remove();
                            $('#Option' + vVarNAMCounter3 + " option[value='>=']").remove();
                            break;

                        case '3':
                            $('#HIGHSEL' + vVarNAMCounter3).attr('disabled', 'disabled');
                            break;

                        case '4':
                            $('#HIGHSEL' + vVarNAMCounter3).attr('disabled', 'disabled');
                            $('#LOWSEL' + vVarNAMCounter3).attr('multiple', 'multiple');
                            $('#Option' + vVarNAMCounter3 + " option[value='Between']").remove();
                            $('#Option' + vVarNAMCounter3 + " option[value='<>']").remove();
                            $('#Option' + vVarNAMCounter3 + " option[value='<']").remove();
                            $('#Option' + vVarNAMCounter3 + " option[value='>']").remove();
                            $('#Option' + vVarNAMCounter3 + " option[value='<=']").remove();
                            $('#Option' + vVarNAMCounter3 + " option[value='>=']").remove();
                            break;
                    }
                    vSELDEFLOW.push(vVarNAMCounter3);                    
                    vSELDEFLOW.push(reply.DEFAULT_LOW);
                    vSELDEFLOW.push(reply.SELECTTYPE);
                    vSELDEFHIGH.push(vVarNAMCounter3);
                    vSELDEFHIGH.push(reply.DEFAULT_HIGH);
                    vSELDEFHIGH.push(reply.SELECTTYPE);
                    namearr.push(reply.NAME.split('~'));
                    $('#Tname' + vVarNAMCounter3).append(arrr);
                    $('#Name' + vVarNAMCounter3).append(namearr[vVarNAMCounter3 - 1]);
                };
            };
            table += '</tr>';
        });
        $('#SetVariables').append(table);
        table = "";

        var vTimeout1 = setTimeout(myTimer1, 2000);
        function myTimer1() {
            $('.selectpicker').selectpicker();
            //console.log(vSELDEFLOW);
            //console.log(vSELDEFLOW.length);
            for (var i = 0; i < vSELDEFLOW.length; i = i+3) {
                var n = i + 1;
                var m = i + 2;
                $('#LOWSEL' + vSELDEFLOW[i]).selectpicker('val', vSELDEFLOW[n]);
                $('#Sign' + vSELDEFLOW[i]).selectpicker('val', 'Include');

                switch (vSELDEFLOW[m]) {
                    case '1':
                        $('#Option' + vSELDEFLOW[i]).selectpicker('val', '=');
                        break;

                    case '2':
                        $('#Option' + vSELDEFLOW[i]).selectpicker('val', 'Between');
                        break;

                    case '3':
                        $('#Option' + vSELDEFLOW[i]).selectpicker('val', '=');
                        break;

                    case '4':
                        $('#Option' + vSELDEFLOW[i]).selectpicker('val', '=');
                        break;
                }
                //console.log(vSELDEFLOW[i]);
                //console.log(vSELDEFLOW[n]);
            }
            for (var i = 0; i < vSELDEFHIGH.length; i = i + 2) {
                var n = i + 1;              
                $('#HIGHSEL' + vSELDEFHIGH[i]).selectpicker('val', vSELDEFHIGH[n]);
                //console.log(vSELDEFHIGH[i]);
                //console.log(vSELDEFHIGH[n]);
            }    
        }
        app.destroySessionObject(reply.qInfo.qId);
    }

    //open apps -- inserted here --
    var app = qlik.openApp(applicationid, config);
    app.clearAll();

    //get objects -- inserted here --
    app.getObject('CurrentSelections', 'CurrentSelections');
    app.getObject('QV01', 'mBUArP');
    app.getObject('QV02', 'pnAUuj');
    app.getObject('QV03', 'PjMtMqh');
    app.getObject('QV04', 'TUjXFp');
    app.getObject('QV05', 'qyJyLCx');
    app.getObject('QV06', 'mAX');


    //create cubes and lists -- inserted here --
    app.createList({
        "qFrequencyMode": "V",
        "qDef": {
            "qFieldDefs": [
                    "QUERY_CAT"
            ]
        },
        "qExpressions": [],
        "qInitialDataFetch": [
                {
                    "qHeight": 10000,
                    "qWidth": 1
                }
        ],
        "qLibraryId": null
    }, showDataInfo);
    app.createList({
        "qFrequencyMode": "V",
        "qDef": {
            "qFieldDefs": [
                    "QUERY_NAME"
            ]
        },
        "qExpressions": [],
        "qInitialDataFetch": [
                {
                    "qHeight": 10000,
                    "qWidth": 1
                }
        ],
        "qLibraryId": null
    }, showDataBex);
    app.createList({
        "qFrequencyMode": "V",
        "qDef": {
            "qFieldDefs": [
                    "DESCRIPTION_QUERY"
            ]
        },
        "qExpressions": [],
        "qInitialDataFetch": [
                {
                    "qHeight": 10000,
                    "qWidth": 1
                }
        ],
        "qLibraryId": null
    }, showDataBexDes);

    app.createGenericObject({
        Load: {
            qStringExpression: "=$(SenseVLoad)"
        },
        Dimensions: {
            qStringExpression: "=$(SenseVDimensions)"
        },
        Measures: {
            qStringExpression: "=$(SenseVMeasures)"
        },
        Unit: {
            qStringExpression: "=$(SenseVUnit)"
        }
    }, showVariables);
    app.createGenericObject({
        Selected: {
            qStringExpression: "=if(GetSelectedCount(QUERY_CAT) < 1 and GetSelectedCount(QUERY_NAME) < 1 and GetSelectedCount(DIM_NAM) < 1 and GetSelectedCount(MES_NAM) < 1 ,if(GetSelectedCount(DIM_NAM) <> 0 and GetSelectedCount(MES_NAM) <> 0 and GetSelectedCount(DESCRIPTION_QUERY) <> 0,1,0),1)"
        },
        SelectedDimensions: {
            qStringExpression: "=if(GetFieldSelections(DIM_NAM)<> null(), Concat(DISTINCT DIM_NAM , ',' ) & ',')"
        },
        SelectedMeasures: {
            qStringExpression: "=if(GetFieldSelections(MES_NAM)<> null(), Concat(DISTINCT MES_NAM , ',' ) & ',')"
        },
        SelectInfoprovider: {
            qStringExpression: "=if(GetFieldSelections(QUERY_CAT)<> null(), Concat(DISTINCT QUERY_CAT , ',' ) & ',')"
        },
        SelectQuery: {
            qStringExpression: "=if(GetFieldSelections(QUERY_NAME)<> null(), Concat(DISTINCT QUERY_NAME , ',' ) & ',')"
        }

    }, function (status) {

        vAppDimensions = status.SelectedDimensions;
        //console.log(vAppDimensions);
        vAppMeasures = status.SelectedMeasures;
        //console.log(vAppMeasures);


        if (status.SelectedDimensions != '-') {
            CheckDim = 1;
        } else {
            CheckDim = 0;
        }

        if (status.SelectedMeasures != '-') {
            CheckMes = 1;
        } else {
            CheckMes = 0;
        }

        if (status.SelectInfoprovider != '-') {
            CheckInfo = 1;
        } else {
            CheckInfo = 0;
        }

        if (status.SelectQuery != '-') {
            CheckQuery = 1;
        } else {
            CheckQuery = 0;
        }

        //console.log('CheckQuery: ' + CheckQuery);
        //console.log('CheckInfo: ' + CheckInfo);
        //console.log('CheckDim: ' + CheckDim);
        //console.log('CheckMes: ' + CheckMes);

        var status = status.Selected;
        if (status == 1) {
            $('#step1').removeClass('active').delay(500).addClass('complete');
            setTimeout(function () {
                $('#step2').addClass('active')
            }, 500);
            $('#step2').removeClass('complete');
            $('#step3').removeClass('complete');
            $('#step4').removeClass('complete');
        } else {
            $('#step1').removeClass('complete');
            $('#step1').addClass('active');
            $('#step2').removeClass('active');
            $('#step2').removeClass('complete');
            $('#step3').removeClass('active');
            $('#step3').removeClass('complete');
            $('#step4').removeClass('active');
            $('#step4').removeClass('complete');
        }

    });

    //SetVariables
    $('#createvariables').on('click', function () {
        vSwitch = 0;
    });
    $('#createvariables, #ModifySetVariables').on('click', function () {

        if (CheckInfo == 0 || CheckDim == 0 || CheckQuery == 0 || CheckMes == 0) {
            $('#ErrorCreateApp').modal('show');
            if (CheckInfo == 0) {
                $('#CheckInfo').show();
            }
            if (CheckQuery == 0) {
                $('#CheckQuery').show();
            }
            if (CheckDim == 0) {
                $('#CheckDim').show();
            }
            if (CheckMes == 0) {
                $('#CheckMes').show();
            }
        } else {

            var vVarNAMCounter1 = 0;
            var vVarNAMCounter2 = 0;
            var vVarNAMCounter3 = 0;
            $('#SetVariables').empty();
            $('#Variables').modal('show');
            ////$('#Variables').slideDown(1000);
            app.createList({
                "qDef": {
                    "qFieldDefs": [
                            "DESCRIPTION_VARIABLE"
                    ]
                },
                "qExpressions": [],
                "qInitialDataFetch": [
                        {
                            "qHeight": 10000,
                            "qWidth": 1
                        }
                ],
                "qLibraryId": null
            }, getVar_NAM);
        }
    });

    //Select Query Button
    $('#step1dot').on('click', function () {
        $('#Queryselector').fadeIn(500);
        $('#Fieldselector').fadeIn(500);
        $('#Loadscript').hide();

        $('#step4').removeClass('active');
        $('#step4').removeClass('complete');

        $('#step3').removeClass('active');
        $('#step3').removeClass('complete');

        $('#step2').removeClass('active');
        $('#step2').removeClass('complete');

        $('#step1').removeClass('complete');
        $('#step1').addClass('active');

        app.clearAll();
        CheckConn = 0;

    });

    //Append Script Step(1)
    $('#createscript').on('click', function () {
        if (CheckDim == 0 || CheckInfo == 0 || CheckMes == 0 || CheckQuery == 0) {
            $('#ErrorCreateApp').modal('show');
            if (CheckInfo == 0) {
                $('#CheckInfo').show();
            }
            if (CheckQuery == 0) {
                $('#CheckQuery').show();
            }
            if (CheckDim == 0) {
                $('#CheckDim').show();
            }
            if (CheckMes == 0) {
                $('#CheckMes').show();
            }
        } else {

            $('code').empty();
            $('#Queryselector').hide();
            $('#Fieldselector').hide();

            $('#Loadscript').fadeIn(500);
        }
    });

    //Append Script Step(2)
    $(document.body).on('click', '#dataconnection li', function (event) {
        var $target = $(event.currentTarget);
        $target.closest('.btn-group')
           .find('[data-bind="label"]').text($target.text())
              .end()
           .children('.dropdown-toggle').dropdown('toggle');


        vDataConnection = "LIB CONNECT TO '" + $('#dataconsel').text() + "';";
        $('#maxscript').show();
        $('code').empty();
        $('#Loadscript2').show();
        $('code').append('\n');
        $('code').append(vDataConnection);
        $('code').append('\n');
        $('code').append('\n');
        $('code').append('[' + vBexQuery + ']: \n');
        $('code').append('<b>LOAD</b> \n');
        $('code').append(vLoad);
        $('code').append('\n<b>SELECT</b> ' + '[' + vBexQuery + ']');
        $('code').append('\n<b>DIMENSIONS</b> (\n');
        $('code').append(vDimensions);
        $('code').append('\n)\n');
        $('code').append('<b>MEASURES</b> (\n');
        $('code').append(vMeasures);
        $('code').append('\n)\n');
        $('code').append('<b>UNITS</b> (\n');
        $('code').append(vUnit);
        $('code').append('\n)\n');
        $('code').append('<b>VARIABLES</b> (\n');
        $('code').append(vVariable);
        $('code').append(')\n');
        $('code').append('<b>FROM</b> [' + vInfoprovider + '];');
        vScript = $('code').text();

        CheckConn = 1;
        //console.log(vScript);

        $('#script').hide();
        $('#step3').removeClass('active').delay(500).addClass('complete');
        setTimeout(function () {
            $('#step4').addClass('active')
        }, 500);
        $('#step4').removeClass('complete');
    });

    //Apply Variables
    $('#applyvariable').on('click', function () {

        var numberOfChecked = $('input:checkbox:checked.MANDATORY').length;
        var numberOfMANDATORY = $('.MANDATORY').length;
        var vcheckmandatorybox = 0;

        if (numberOfChecked == numberOfMANDATORY) {
            vVariable = [];
            var array = [];
            var curIndex = 0;
            var curIndex2 = 0;
            var Ende = 0;

            $(':checkbox:checked').each(function () {
                var id = $(this).attr('id');
                if (id.length == 6) {
                    num = id.substr(id.length - 1);
                } else {
                    num = id.substr(id.length - 2);
                }
                array.push(num);
                Ende = array.length;
            });

            function doNext() {
                var num = array[curIndex];
                var TRIGGER = null
                var TNAME = "";
                var SIGN = "";
                var OPTION = "";

                //LOW

                var LOWarray = [];

                $('[data-id="LOWSEL' + num + '"]').next("div").find("li.selected > a > span.text").each(function () {
                    //console.log($(this).first().context.firstChild.nodeValue);
                    //console.log($(this).first().context.lastChild.innerText);
                    LOWarray.push($(this).first().context.lastChild.innerText);

                });

                //console.log(LOWarray.length);

                if (LOWarray.length == 1) {            

                    LOW = 'LOW=' + LOWarray.join(", ");
                    //console.log(LOW)
                    //var a = $('[data-id="LOWSEL' + num + '"] > span').text();
                    //LOW = $('option:contains(' + a + ')').attr("data-subtext");
                    //LOW = 'LOW=' + LOW;

                    //console.log(LOW);


                    //HIGH
                    var b = $('[data-id="HIGHSEL' + num + '"] > span').text();
                    HIGH = $('option:contains(' + b + ')').attr("data-subtext");
                    //console.log(HIGH);
                    if (HIGH != undefined) {
                        HIGH = ', HIGH=' + HIGH;
                    } else {
                        HIGH = '';
                    }
                    //console.log(HIGH);

                    //Name
                    TNAME = $('#Tname' + num).text();
                    TNAME = TNAME.replace('[', '');
                    TNAME = TNAME.replace(']', '');
                    TNAME = 'NAME=' + TNAME + ',';
                    //console.log(TNAME);

                    //SIGN
                    SIGN = $('[data-id="Sign' + num + '"] > span').text();
                    switch (SIGN) {
                        case 'Include':
                            SIGN = "SIGN=I,";
                            break;
                        case 'Exclude':
                            SIGN = "SIGN=E,";
                            break;
                        case 'nothing selected':
                            SIGN = "SIGN=NOTHING_SELECTED,";
                            break;
                    }
                    //console.log(SIGN);

                    //OPTION
                    OPTION = $('[data-id="Option' + num + '"] > span').text();
                    switch (OPTION) {
                        case '=':
                            OPTION = "OPTION=EQ,";
                            break;
                        case '<>':
                            OPTION = "OPTION=NE,";
                            break;
                        case '<':
                            OPTION = "OPTION=LT,";
                            break;
                        case '>':
                            OPTION = "OPTION=GT,";
                            break;
                        case '<=':
                            OPTION = "OPTION=LE,";
                            break;
                        case '>=':
                            OPTION = "OPTION=GE,";
                            break;
                        case 'Between':
                            OPTION = "OPTION=BT,";
                            break;
                        case 'nothing selected':
                            OPTION = "OPTION=NOTHING_SELECTED,";
                            break;
                    }
                    //console.log(OPTION);

                    //OUTPUT
                    vVariable += '[' + TNAME + ' ' + SIGN + ' ' + OPTION + ' ' + LOW + HIGH +'],\n'
                    //console.log(vVariable);
                }
                else
                {
                    for (curIndex2 = 0; curIndex2 < LOWarray.length; curIndex2++) {

                        LOW = 'LOW=' + LOWarray[curIndex2];
                        //console.log(LOW)
                        //var a = $('[data-id="LOWSEL' + num + '"] > span').text();
                        //LOW = $('option:contains(' + a + ')').attr("data-subtext");
                        //LOW = 'LOW=' + LOW;

                        //console.log(LOW);


                        //HIGH
                        var b = $('[data-id="HIGHSEL' + num + '"] > span').text();
                        HIGH = $('option:contains(' + b + ')').attr("data-subtext");
                        //console.log(HIGH);
                        if (HIGH != undefined) {
                            HIGH = ', HIGH=' + HIGH;
                        } else {
                            HIGH = '';
                        }
                        //console.log(HIGH);

                        //Name
                        TNAME = $('#Tname' + num).text();
                        TNAME = TNAME.replace('[', '');
                        TNAME = TNAME.replace(']', '');
                        TNAME = 'NAME=' + TNAME + ',';
                        //console.log(TNAME);

                        //SIGN
                        SIGN = $('[data-id="Sign' + num + '"] > span').text();
                        switch (SIGN) {
                            case 'Include':
                                SIGN = "SIGN=I,";
                                break;
                            case 'Exclude':
                                SIGN = "SIGN=E,";
                                break;
                            case 'nothing selected':
                                SIGN = "SIGN=NOTHING_SELECTED,";
                                break;
                        }
                        //console.log(SIGN);

                        //OPTION
                        OPTION = $('[data-id="Option' + num + '"] > span').text();
                        switch (OPTION) {
                            case '=':
                                OPTION = "OPTION=EQ,";
                                break;
                            case '<>':
                                OPTION = "OPTION=NE,";
                                break;
                            case '<':
                                OPTION = "OPTION=LT,";
                                break;
                            case '>':
                                OPTION = "OPTION=GT,";
                                break;
                            case '<=':
                                OPTION = "OPTION=LE,";
                                break;
                            case '>=':
                                OPTION = "OPTION=GE,";
                                break;
                            case 'Between':
                                OPTION = "OPTION=BT,";
                                break;
                            case 'nothing selected':
                                OPTION = "OPTION=NOTHING_SELECTED,";
                                break;
                        }
                        //console.log(OPTION);

                        //OUTPUT
                        vVariable += '[' + TNAME + ' ' + SIGN + ' ' + OPTION + ' ' + LOW + HIGH + '],\n'
                    }

                }
            };

            for (curIndex = 0; curIndex < array.length; curIndex++) {
                doNext();
            }


            $('#Variables').modal('hide');
            if (vSwitch == 0) {
                $('#step2').removeClass('active').delay(500).addClass('complete');
                setTimeout(function () {
                    $('#step3').addClass('active')
                }, 500);

                $('#step3').removeClass('complete');
                $('#step4').removeClass('complete');
                $('#step4').removeClass('active');
            }
        } else {
            $('#ErrorVariable').modal('show');
        }
    });
    //______________________________________________________________________________________________________
    //______________________________________________________________________________________________________

    //Create App
    $('#createapp').on('click', function () {

            var vApp = "";
            var vAppID = "";
            var vTimestamp = timeStamp();
            var notify = "";

            if (CheckDim == 0 || CheckInfo == 0 || CheckMes == 0 || CheckQuery == 0 || CheckConn == 0) {
                $('#ErrorCreateApp').modal('show');
                if (CheckInfo == 0) {
                    $('#CheckInfo').show();
                }
                if (CheckQuery == 0) {
                    $('#CheckQuery').show();
                }
                if (CheckDim == 0) {
                    $('#CheckDim').show();
                }
                if (CheckMes == 0) {
                    $('#CheckMes').show();
                }
                if (CheckConn == 0) {
                    $('#CheckConn').show();
                }
            } else {
                /* Create APP */
                const qsocks = require(applicationfolder + "/js/qsocks.bundle");

                qsocks.Connect(config).then(function (global) {
                    global.productVersion().then(function (version) {
                        $.notify({ icon: 'glyphicon glyphicon-ok', message: 'Connection to Server establised.' }, { type: 'success', placement: { from: 'bottom', align: 'right' } });
                        vApp = vNamespace + vBexQuery + '_' + vTimestamp;
                        return global.createApp('Query_' + vBexQuery + '_' + vTimestamp);
                    })

                    .then(function (reply) {
                        $.notify({ icon: 'glyphicon glyphicon-ok', message: 'APP: <b>' + vApp + '</b> created successfully. ID: ' + '<b>' + reply.qAppId + '</b>' }, { type: 'success', placement: { from: 'bottom', align: 'right' } }, { newest_on_top: true });
                        // Establish a new connection so we don't pollute the current engine session.
                        vAppID = reply.qAppId;
                        return qsocks.ConnectOpenApp({
                            host: window.location.hostname,
                            prefix: "/",
                            port: window.location.port,
                            isSecure: window.location.protocol === "https:",
                            rejectUnauthorized: false,
                            appname: reply.qAppId,
                            debug: true
                        });
                    })
                    .then(function (conns) {
                        var app = conns[1];
                        //console.log(conns);
                        var myscript = vScript;
                        myscript += '\n//SAPSCRIPT';
                        return app.getEmptyScript('Main').then(function (script) {
                            var localsettings = "";
                            localsettings += "///$tab Main\r\n";
                            localsettings += "SET ThousandSep=',';\n";
                            localsettings += "SET DecimalSep='.';\n";
                            localsettings += "SET MoneyThousandSep=',';\n";
                            localsettings += "SET MoneyDecimalSep='.';\n";
                            localsettings += "SET MoneyFormat='#.##0,00 €;-#.##0,00 €';\n";
                            localsettings += "SET TimeFormat='hh:mm:ss';\n";
                            localsettings += "SET DateFormat='DD.MM.YYYY';\n";
                            localsettings += "SET TimestampFormat='DD.MM.YYYY hh:mm:ss[.fff]';\n";
                            localsettings += "SET MonthNames='Jan;Feb;Mrz;Apr;Mai;Jun;Jul;Aug;Sep;Okt;Nov;Dez';\n";
                            localsettings += "SET DayNames='Mo;Di;Mi;Do;Fr;Sa;So';\n";
                            localsettings += "SET LongMonthNames='Januar;Februar;März;April;Mai;Juni;Juli;August;September;Oktober;November;Dezember';\n";
                            localsettings += "SET LongDayNames='Montag;Dienstag;Mittwoch;Donnerstag;Freitag;Samstag;Sonntag';\n";
                            localsettings += "SET FirstWeekDay=0;\n";
                            localsettings += "SET BrokenWeeks=0;\n";
                            localsettings += "SET ReferenceDay=4;\n";
                            localsettings += "SET FirstMonthOfYear=1;\n";
                            localsettings += "SET CollationLocale='de-DE';\n";
                            localsettings += "///$tab SAP\r\n";
                            // localsettings += "///$autogenerated\r\n"
                            localsettings += '\n//SAPSCRIPT'


                            return app.setScript(localsettings + myscript)
                        })

                    // Reload
                        .then(function () {
                            $.notify({ icon: 'glyphicon glyphicon-ok', message: 'LoadScript appended successfully.' }, { type: 'success', placement: { from: 'bottom', align: 'right' } });
                            notify = $.notify({ icon: 'glyphicon glyphicon-refresh glyphicon-refresh-animate', message: 'Indexing application...' }, { type: 'info', timer: '1000000', placement: { from: 'bottom', align: 'right' } });
                            console.log('Reload:');

                            app.doReload().then(function () {
                                reloaded = true;
                            })
                                // Save
                                .then(function () {
                                    notify.close();
                                    $.notify({ icon: 'glyphicon glyphicon-ok', message: 'Application created successfully.' }, { type: 'success', placement: { from: 'bottom', align: 'right' } })
                                    notify = $.notify({ icon: 'glyphicon glyphicon-refresh glyphicon-refresh-animate', message: 'Saving application...' }, { type: 'info', timer: '1000000', placement: { from: 'bottom', align: 'right' } });
                                    console.log('Save:');
                                    return app.doSave()
                                })
                                .then(function () {
                                    notify.close();
                                    $.notify({ icon: 'glyphicon glyphicon-ok', message: 'App saved successfully.' }, { type: 'success', placement: { from: 'bottom', align: 'right' } });
                                    console.log('Done')
                                    var vurl = vsiteurl + vAppID;
                                    $.notify({ icon: 'glyphicon glyphicon-log-in', message: 'Click to open App', url: vurl }, { type: 'info', timer: '10000', placement: { from: 'bottom', align: 'right' } });
                                    $('#step4').removeClass('active').delay(500).addClass('complete');

                                    ////insert Variables
                                    var appresult = qlik.openApp(vAppID, config);
                                    appresult.variable.create({
                                        qName: 'cInfoprovider',
                                        qDefinition: vInfoprovider
                                    });
                                    appresult.variable.create({
                                        qName: 'cBExQuery',
                                        qDefinition: vBexQuery
                                    });
                                    appresult.variable.create({
                                        qName: 'cBExQueryDes',
                                        qDefinition: vBexQueryDes
                                    });
                                    appresult.variable.create({
                                        qName: 'cDataCon',
                                        qDefinition: vDataConnection
                                    });
                                    appresult.variable.create({
                                        qName: 'cDimensions',
                                        qDefinition: vAppDimensions
                                    });
                                    appresult.variable.create({
                                        qName: 'cMeasures',
                                        qDefinition: vAppMeasures
                                    });

                                })

                            reloaded = null;
                            var progress = setInterval(function () {

                                if (reloaded != true) {
                                    conns[0].getProgress(5).then(function (msg) {
                                        //console.log(msg);
                                        if (msg.qPersistentProgress) {
                                            persistentProgress = msg.qPersistentProgress;
                                            console.log(msg.qPersistentProgress + ' <-- ' + msg.qTransientProgress)
                                        } else {
                                            if (msg.qTransientProgress) {
                                                console.log(persistentProgress + ' <-- ' + msg.qTransientProgress)
                                            }
                                        }
                                    })
                                } else {
                                    clearInterval(progress)
                                }
                            }, 2000);
                        })
                    })
                .catch(function (err) {
                    $.notify({ icon: 'glyphicon glyphicon-warning-sign', message: 'Error ' + err.code + ': ' + err.message }, { type: 'danger', timer: '10000', placement: { from: 'bottom', align: 'right' } });
                    console.log(err) // Handle errors
                })
                })
            }
    });
    //______________________________________________________________________________________________________
    //______________________________________________________________________________________________________

    //Building Timestamps
    function timeStamp() {
        // Create a date object with the current time
        var now = new Date();

        // Create an array with the current month, day and time
        var date = [now.getMonth() + 1, now.getDate(), now.getFullYear()];

        // Create an array with the current hour, minute and second
        var time = [now.getHours(), now.getMinutes(), now.getSeconds()];

        // Determine AM or PM suffix based on the hour
        var suffix = (time[0] < 12) ? "AM" : "PM";

        // Convert hour from military time
        //time[0] = (time[0] < 12) ? time[0] : time[0] - 12;

        // If hour is 0, set it to 12
        time[0] = time[0] || 12;

        // If seconds and minutes are less than 10, add a zero
        for (var i = 1; i < 3; i++) {
            if (time[i] < 10) {
                time[i] = "0" + time[i];
            }
        }

        // Return the formatted string
        var tmp = date.join() + "_" + time.join();
        return tmp.replace(/,/g, "");

    }
    if (app) {
        new AppUi(app);
    }

    //Select all Measures Button
    $('#selallbuttonmea, #selallbuttonmea2').on('click', function () {
        app.field('MES_NAM').selectAll();
    });

    //Select all Dimensions Button
    $('#selallbuttondim, #selallbuttondim2').on('click', function () {
        app.field('DIM_NAM').selectAll();
    });

    //Enable Tooltips
    $('i').tooltip();

    //Get DataConnections from API @ start
    $(document).ready(function () {
        var vConnection = [];
        const qsocks = require(applicationfolder + "/js/qsocks.bundle");
        var global = qsocks.Connect(config);
        global.then(function (global) {
            return qsocks.ConnectOpenApp({
                host: window.location.hostname,
                prefix: "/",
                port: window.location.port,
                isSecure: window.location.protocol === "https:",
                rejectUnauthorized: false,
                appname: applicationid,
                debug: true
            });
        })
        .then(function (reply) {
            return (reply[1].getConnections());
        }).then(function (connection) {
            $.each(connection, function () {
                vConnection.push(this.qName);
                $('#dataconnection').append('<li><a href="#" data-value="' + this.qName + '">' + this.qName + '</a></li>');
                $('#connectionmodify').append('<li><a href="#" data-value="' + this.qName + '">' + this.qName + '</a></li>');
            });
        });
    });

    //Modals
    $(document).ready(function () {
        if ($.cookie("no_thanks") == null) {
            $('#startModal').appendTo("body");
            function show_modal() {
                $('#startModal').modal();
            }
            window.setTimeout(show_modal, 1000);
        }
        $(".nothanks").click(function () {
            document.cookie = "no_thanks=true; expires=Fri, 31 Dec 9999 23:59:59 UTC";
        });
    });

    //Modify App

    //Dropdown pick Datacon
    $(document.body).on('click', '#connectionmodify li a', function (event) {
        var $target = $(event.currentTarget);
        var targetapp;
        $target.closest('.btn-group')
           .find('[data-bind="label"]').text($target.text())
              .end()
           .children('.dropdown-toggle').dropdown('toggle');
    });

    //Dropdown switch App
    $(document.body).on('click', '#appselection li a', function (event) {
        var $target = $(event.currentTarget);
        $target.closest('.btn-group')
           .find('[data-bind="label"]').text($target.text())
              .end()
           .children('.dropdown-toggle').dropdown('toggle');
        targetapp = $(this).attr('value');

        var appmod = qlik.openApp(targetapp, config);
        appmod.createGenericObject({
            Infoprovider: {
                qStringExpression: "=cInfoprovider"
            },
            BexQuery: {
                qStringExpression: "=cBExQuery"
            },
            BexQueryDes: {
                qStringExpression: "=cBExQueryDes"
            },
            DataCon: {
                qStringExpression: "=cDataCon"
            },
            AppDimensions: {
                qStringExpression: "=left(cDimensions ,len(cDimensions)-1)"
            },
            AppMeasures: {
                qStringExpression: "=left(cMeasures ,len(cMeasures)-1)"
            }
        }, function (reply) {
            $('#QueryPropertiesInfo').empty();
            $('#QueryPropertiesBex').empty();
            $('#QueryPropertiesBexDes').empty();
            $('#QueryPropertiesDataCon').empty();
            $('#QueryPropertiesInfo').append(reply.Infoprovider);
            $('#QueryPropertiesBex').append(reply.BexQuery);
            $('#QueryPropertiesBexDes').append(reply.BexQueryDes);
            $('#QueryPropertiesDataCon').append(reply.DataCon);
            vDataConnection = reply.DataCon;

            //Apply Selection
            var vInfotemp = [];
            vInfotemp.push(reply.Infoprovider);
            var vBextemp = [];
            vBextemp.push(reply.BexQuery);
            var vBexDsctemp = [];
            vBexDsctemp.push(reply.BexQueryDes);

            var vAppDimtemp = reply.AppDimensions;
            var vAppDim = vAppDimtemp.split(',');

            var vAppMestemp = reply.AppMeasures;
            var vAppMes = vAppMestemp.split(',');

            app.clearAll();

            var vTimeout1 = setTimeout(myTimer1, 300);
            function myTimer1() {
                app.field('QUERY_CAT').selectValues(vInfotemp, true, true);
                app.field('QUERY_NAME').selectValues(vBextemp, true, true);
                app.field('DESCRIPTION_QUERY').selectValues(vBexDsctemp, true, true);
                app.field('DIM_NAM').selectValues(vAppDim, true, true);
                app.field('MES_NAM').selectValues(vAppMes, true, true);
            }
        });
    });

    $('#modifyapp').on('click', function () {
        $('#appselection').empty();
        qlik.getGlobal(config).getAppList(function (list) {
            var abc = "";
            $.each(list, function (key, value) {
                var c = vNamespace.length;
                var d = value.qDocName.substring(0, c);
                if (vNamespace == d) {
                    abc += value.qDocName + ' ' + value.qDocId;
                    $("#appselection").append('<li><a href="#" value="' + value.qDocId + '">' + value.qDocName + '</a></li>');
                }
            });
        });

        $('#ModifyAppModal').modal('show');
        app.getObject('QV09', 'PjMtMqh');
        app.getObject('QV10', 'TUjXFp');

        var vTimeout1 = setTimeout(myTimer1, 50);
        function myTimer1() {
            qlik.resize();
        }
    });

    //Clear Variables
    $('#ModifySetVariablesClear').on('click', function () {
        vVariable = '';
        $('#ModifySetVariablesClear').removeClass('btn-default');
        $('#ModifySetVariablesClear').addClass('btn-success');
    });


    $('#Modifyfinished, #ModifySetVariables').on('click', function () {
        vSwitch = 1;
        CheckMod = 1;
        $('#Loadscript, #Queryselector, #Fieldselector').hide();
        $('#step1, #step2, #step3, #step4, #step5').removeClass('active').addClass('complete');
        $('#step1, #step2, #step3, #step4').removeClass('active').addClass('white');
        $('#step1progress, #step1dot, #step1text').fadeOut();
        $('#step2progress, #createvariables, #step2text').fadeOut();
        $('#step3progress, #createscript, #step3text').fadeOut();
        $('#step4progress, #createapp, #step4text').fadeOut();
        $('#step6').addClass('active')
    });

    // Reload Modified App
    $('#reloadmodifiedapp').on('click', function () {

        if (CheckMod == 0) {
            $('#ErrorCreateApp').modal('show');
            $('#CheckMod').show();
        } else {

            var notify = "";

            //Set Variables to current selection
            var appresult = qlik.openApp(targetapp, config);
            //console.log(vAppDimensions);
            appresult.variable.setContent('cDimensions', vAppDimensions);
            //console.log(vAppMeasures);
            appresult.variable.setContent('cMeasures', vAppMeasures);

            var vTimeout2 = setTimeout(myTimer2, 1000);
            function myTimer2() {

                const qsocks = require(applicationfolder + "/js/qsocks.bundle");
                // Get a global reference
                var global = qsocks.Connect(config);
                global.then(function (reply) {
                    $.notify({ icon: 'glyphicon glyphicon-ok', message: 'Connection to Application establised.' }, { type: 'success', placement: { from: 'bottom', align: 'right' } }, { newest_on_top: true });
                    return qsocks.ConnectOpenApp({
                        host: window.location.hostname,
                        prefix: "/",
                        port: window.location.port,
                        isSecure: window.location.protocol === "https:",
                        rejectUnauthorized: false,
                        appname: targetapp,
                        debug: true
                    });
                })
                .then(function (conns) {
                    var app = conns[1];
                    // Load scripts in Qlik is just a string
                    var myscript;

                    // Get a empty script to get correct locale variables
                    return app.getScript().then(function (script) {

                        var vScript = script;
                        //console.log(vScript);

                        myscript = '';
                        myscript += "///$tab SAP\r\n";
                        // myscript += "///$autogenerated\r\n"         
                        myscript += '//SAPSCRIPT';
                        myscript += '\n';
                        myscript += vDataConnection + '\n';
                        myscript += '[' + vBexQuery + ']: \n'
                        myscript += 'LOAD \n';
                        myscript += vLoad;
                        myscript += '\n';
                        myscript += 'SELECT [' + vBexQuery + ']';
                        myscript += '\n';
                        myscript += 'DIMENSIONS (\n';
                        myscript += vDimensions;
                        myscript += '\n)\n';
                        myscript += 'MEASURES ( \n';
                        myscript += vMeasures;
                        myscript += '\n)\n';
                        myscript += 'UNITS ( \n';
                        myscript += vUnit;
                        myscript += '\n)\n';
                        myscript += 'VARIABLES ( \n';
                        myscript += vVariable;
                        myscript += '\n)\n';
                        myscript += 'FROM [' + vInfoprovider + '];'
                        myscript += '\n//SAPSCRIPT';

                        var Finalscript = vScript.replace(/(?:\/\/\/\$tab SAP)[^]+(?:\/\/SAPSCRIPT)/g, myscript);
                        //console.log(Finalscript);
                        return app.setScript(Finalscript);

                    })
                // Reload
                .then(function () {
                    $.notify({ icon: 'glyphicon glyphicon-ok', message: 'Query definition appended successfully.' }, { type: 'success', placement: { from: 'bottom', align: 'right' } });
                    notify = $.notify({ icon: 'glyphicon glyphicon-refresh glyphicon-refresh-animate', message: 'Indexing application...' }, { type: 'info', timer: '1000000', placement: { from: 'bottom', align: 'right' } });
                    console.log('Reload:');
                    return app.doReload()
                })
                // Save
                .then(function () {
                    notify.close();
                    $.notify({ icon: 'glyphicon glyphicon-ok', message: 'Application reloaded successfully.' }, { type: 'success', placement: { from: 'bottom', align: 'right' } })
                    notify = $.notify({ icon: 'glyphicon glyphicon-refresh glyphicon-refresh-animate', message: 'Saving application...' }, { type: 'info', timer: '1000000', placement: { from: 'bottom', align: 'right' } });

                    console.log('Save:');
                    return app.doSave()
                })
                })
                // Clean Up
                .then(function () {
                    notify.close();
                    $.notify({ icon: 'glyphicon glyphicon-ok', message: 'App saved successfully.' }, { type: 'success', placement: { from: 'bottom', align: 'right' } });
                    console.log('Done')
                    var vurl = vsiteurl + targetapp;
                    $.notify({ icon: 'glyphicon glyphicon-log-in', message: 'Click to open App', url: vurl }, { type: 'info', timer: '10000', placement: { from: 'bottom', align: 'right' } });
                    $('#step6').removeClass('active').delay(500).addClass('complete');
                })
                .catch(function (err) {
                    $.notify({ icon: 'glyphicon glyphicon-warning-sign', message: 'Error ' + err.code + ': ' + err.message }, { type: 'danger', timer: '10000', placement: { from: 'bottom', align: 'right' } });
                    console.log(err) // Handle errors
                })
            }
        }
    });

    //minimize  and maximize section Measures & Dimensions
    $('#minvalue').on('click', function () {
        $('#selvalues').fadeOut();
        $('#minvalue').hide();
        $('#maxvalue').show();
    });
    $('#maxvalue').on('click', function () {
        $('#selvalues').fadeIn();
        $('#maxvalue').hide();
        $('#minvalue').show();
        qlik.resize();
    });

    //minimize  and maximize section Infoprovider & Query
    $('#minquery').on('click', function () {
        $('#selquery').fadeOut();
        $('#minquery').hide();
        $('#maxquery').show();
    });
    $('#maxquery').on('click', function () {
        $('#selquery').fadeIn();
        $('#maxquery').hide();
        $('#minquery').show();
        qlik.resize();
    });

    //minimize  and maximize section Script
    $('#minscript').on('click', function () {
        $('#script').fadeOut();
        $('#minscript').hide();
        $('#maxscript').show();
    });
    $('#maxscript').on('click', function () {
        $('#script').fadeIn();
        $('#maxscript').hide();
        $('#minscript').show();
    });

    //Clear Error Dialog
    $('#ErrorCloseMod').on('click', function () {
            $('#CheckInfo').hide();
            $('#CheckQuery').hide();
            $('#CheckDim').hide();
            $('#CheckMes').hide();
            $('#CheckConn').hide();
            $('#CheckMod').hide();
    });

});