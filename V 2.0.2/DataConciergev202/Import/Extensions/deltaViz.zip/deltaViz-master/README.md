deltaViz
========

deltaViz self service dashboard extension for Qlik Sense

![Alt text](/preview.png?raw=true "deltaViz dashboard for Qlik Sense")

Under terms of use and licence : [LICENCE](https://github.com/yblake/deltaViz/blob/master/LICENSE)

See demonstration video : [Build your own executive dashboard in 1 mn with Qlik Sense](http://youtu.be/4s30AEf4qJc).

Installation :
==============
Qlik Sense desktop 

  copy all files in extensions folder (i.e.  C:\Users\<username>\Documents\Qlik\Sense\Extensions).

Qlik Sense Server
  
  See instructions <a href="http://help.qlik.com/en-US/sense/2.1/Subsystems/ManagementConsole/Content/import-extensions.htm?q=extension">Importing extensions</a>

